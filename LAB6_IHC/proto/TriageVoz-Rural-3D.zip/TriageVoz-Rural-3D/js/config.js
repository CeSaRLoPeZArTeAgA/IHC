// ============================================================
// CONFIGURACIÓN LOCAL DE GEMINI
// ============================================================
// 1) Entra a Google AI Studio: https://aistudio.google.com/
// 2) Crea/copia una API key.
// 3) Reemplaza SOLO el texto PEGA_AQUI_TU_API_KEY.
//
// IMPORTANTE: este archivo está ignorado por .gitignore.
// No publiques una API key real en GitHub.

export const API_KEY = 'PEGA_AQUI_TU_API_KEY';

// El LAB06 usa gemini-2.0-flash en el ejemplo.
// Si Google AI Studio indica que ese modelo no está disponible para tu clave,
// cambia SOLO este valor por un modelo habilitado en tu cuenta.
export const GEMINI_MODEL = 'gemini-2.0-flash';
